package hu.bme.szoftlab4.SZLAMB.View;

public enum ViewType {
	TUNDE,
	TORP,
	HOBBIT,
	EMBER,
	TORONY,
	AKADALY,
	VEGZETHEGYE,
	UT,
	URESMEZO, NONE
}
