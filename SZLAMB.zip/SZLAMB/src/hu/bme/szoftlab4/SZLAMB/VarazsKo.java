package hu.bme.szoftlab4.SZLAMB;

/**
 * Ez az enum valósítja meg a program objektumai által
 * tulajdonságok meghatározására használt VarázsKöveket.
 * 
 * @author Erhard Pfisztner
 *
 */
public enum VarazsKo {
	TUNDE,
	TORP,
	HOBBIT,
	NINCS,
	EMBER,
	HATOTAV,
	TUZELES;
}
