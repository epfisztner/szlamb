package hu.bme.szoftlab4.SZLAMB;

/**
 * Ez az enum val�s�tja meg a program objektumai �ltal
 * tulajdons�gok meghat�roz�s�ra haszn�lt Var�zsK�veket.
 * 
 * @author Erhard Pfisztner
 *
 */
public enum VarazsKo {
	TUNDE,
	TORP,
	HOBBIT,
	NINCS,
	EMBER,
	HATOTAV,
	TUZELES;
}
